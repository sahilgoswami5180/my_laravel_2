<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class AccountDeletionNotice extends Mailable
{
    use Queueable, SerializesModels;

    public $user;

    /**
     * Create a new message instance.
     *
     * @param  \App\Models\User  $user
     * @return void
     */
    public function __construct($user)
    {
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        // Fallback for when deleted_at is null
        $deletionTime = $this->user->deleted_at
            ? $this->user->deleted_at->toFormattedDateString()
            : 'Unknown';  // Default value if deleted_at is null

        return $this->subject('Account Deletion Notice')
            ->view('emails.account-deletion-notice') // Ensure this view exists
            ->with([
                'name' => $this->user->name,
                'deletionTime' => $deletionTime,  // Pass the formatted deletion time
            ]);
    }
}
