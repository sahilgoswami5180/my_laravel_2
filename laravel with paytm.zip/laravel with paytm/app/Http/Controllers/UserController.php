<?php

namespace App\Http\Controllers;

use App\Jobs\DeleteUserAccount;
use App\Mail\AccountDeletionNotice;
use App\Models\Product;
use App\Models\Category;
use App\Models\CartItem;
use App\Models\Combo;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\SupportRequest;
use App\Models\Wishlist;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    /**
     * Show the user dashboard or main user page.
     */
    public function index(Request $request)
    {
        // Get categories for filtering
        $categories = Category::all();

        // Start with fetching all active products
        $products = Product::where('status', 'active');

        // Get cart items from session (or database if persistent cart)
        $cartItems = CartItem::where('user_id', auth()->id())->get()->keyBy('product_id');

        // Get wishlist from session
        $wishlist = session()->get('wishlist', []);

        // Return view with products, categories, cart items, and wishlist
        return view('user.index', compact('products', 'categories', 'cartItems', 'wishlist'));
    }


    public function shop(Request $request)
    {
        // Validate the incoming request
        $validated = $request->validate([
            'category_id' => 'nullable|array',
            'category_id.*' => 'exists:categories,id', // Ensure each category_id exists in the categories table
            'subcategory_id' => 'nullable|array',
            'subcategory_id.*' => 'exists:subcategories,id', // Ensure each subcategory_id exists in the subcategories table
            'price_max' => 'nullable|numeric|min:0|max:1000000', // Price should be a number between 0 and 1,000,000
            'sort' => 'nullable|in:relevant,popular,new', // Only allow certain values for sort
            'search' => 'nullable|string|max:255', // Ensure search is a string and not too long
        ]);

        // Get categories for filtering
        $categories = Category::all();

        // Start with fetching all active products
        $products = Product::where('status', 'active');

        // Apply category filter if category or subcategory is selected
        $categoryIds = $request->category_id ?? [];
        if (!empty($categoryIds)) {
            // If 'All Categories' is selected, we don't filter by category
            if (in_array('all', $categoryIds)) {
                $categoryIds = Category::pluck('id')->toArray(); // Get all category IDs
            }

            // Apply the category filter if specific categories are selected
            if (count($categoryIds) > 0) {
                $products = $products->whereIn('category_id', $categoryIds);
            }
        }

        // Apply subcategory filter if selected
        if ($request->has('subcategory_id') && !empty($request->subcategory_id)) {
            $subcategoryIds = $request->subcategory_id;
            $products = $products->whereIn('subcategory_id', $subcategoryIds);
        }

        // Apply price filter if a max price is selected
        if ($request->has('price_max') && is_numeric($request->price_max)) {
            $priceMax = (float) $request->price_max;
            if ($priceMax > 0) {
                $products = $products->where('price', '<=', $priceMax);
            }
        }

        // Apply search filter if there's a search query
        if ($request->has('search') && $request->search != '') {
            $products = $products->where('name', 'like', '%' . $request->search . '%');
        }

        // Apply sorting based on user selection
        if ($request->has('sort') && $request->sort !== '') {
            switch ($request->sort) {
                case 'popular':
                    // Sort by popularity (assuming 'orders_count' is a metric for popularity)
                    $products = $products->withCount('orders')  // Count orders related to each product
                        ->orderByDesc('orders_count');  // Order by order count (popularity)
                    break;

                case 'new':
                    // Sort by latest added (based on created_at or similar field)
                    $products = $products->orderByDesc('created_at');  // Sort by creation date (latest first)
                    break;

                case 'relevant':
                    // Default sorting (could be name, or another criteria you consider "relevant")
                    $products = $products->orderBy('name');  // Default sorting by name
                    break;
            }
        } else {
            // Default sort if no sort option is provided (for example, by creation date)
            $products = $products->orderByDesc('created_at');
        }

        // Fetch the filtered and sorted products with pagination
        $products = $products->get();  // Paginate products (10 per page)

        // Get cart items from session (or database if persistent cart)
        $cartItems = CartItem::where('user_id', auth()->id())->get()->keyBy('product_id');

        // Get wishlist from session
        $wishlist = session()->get('wishlist', []);

        // Fetch combos for display with filtering and pagination
        $combos = Combo::with(['category', 'subcategory', 'products']);

        // Apply filtering to combos based on category and subcategory
        if ($request->has('category_id') && !empty($categoryIds)) {
            // If 'All Categories' is selected, we don't filter by category
            if (in_array('all', $categoryIds)) {
                $combos = $combos->whereHas('category', function ($query) {
                    $query->whereIn('id', Category::pluck('id')->toArray());
                });
            } else {
                // Apply filtering based on category_ids
                $combos = $combos->whereHas('category', function ($query) use ($categoryIds) {
                    $query->whereIn('id', $categoryIds);
                });
            }
        }

        // Apply subcategory filter to combos
        if ($request->has('subcategory_id') && !empty($request->subcategory_id)) {
            $combos = $combos->whereHas('subcategory', function ($query) use ($request) {
                $query->whereIn('id', $request->subcategory_id);
            });
        }

        // Apply sorting to combos (if applicable)
        if ($request->has('sort') && $request->sort !== '') {
            switch ($request->sort) {
                case 'popular':
                    // Example sorting for combos by number of orders (or another field)
                    $combos = $combos->withCount('orders')  // Count orders related to each combo
                        ->orderByDesc('orders_count');  // Order by order count (popularity)
                    break;

                case 'new':
                    $combos = $combos->orderByDesc('created_at');  // Sort by creation date (latest first)
                    break;

                case 'relevant':
                    $combos = $combos->orderBy('name');  // Default sorting by name
                    break;
            }
        } else {
            $combos = $combos->orderByDesc('created_at');  // Default sort by creation date
        }

        // Paginate combos (5 per page for now)
        $combos = $combos->paginate(5);

        // Return view with products, categories, cart items, wishlist, and combos
        return view('shop.index', compact('products', 'categories', 'cartItems', 'wishlist', 'combos'));
    }


    public function seemorecombos()
    {
        $combos = Combo::all();

        return view('shop.combos', compact('combos'));
    }


    /**
     * Show products for a specific category.
     */
    public function categorywiseshow($categoryId)
    {
        // Fetch category by ID or throw 404 if not found
        $category = Category::findOrFail($categoryId);

        // Fetch products associated with the category
        $products = Product::where('category_id', $categoryId)->where('status', 'active')->paginate(10);

        // Check if the category has no products
        if ($products->isEmpty()) {
            return back()->with('error', 'No products found for this category.');
        }

        // Return the view with the category and products
        return view('shop.categorywiseproduct', compact('category', 'products'));
    }

    /**
     * Show product details.
     */
    public function showproducts($id)
    {
        $category = Category::all();
        $product = Product::with('category')->findOrFail($id);
        $cartItems = CartItem::where('user_id', auth()->id())->get()->keyBy('product_id');

        // Get wishlist from session
        $wishlist = session()->get('wishlist', []);

        // Fetch related products from the same category, excluding the current product
        $relatedProducts = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->limit(6) // Limit the number of related products to display
            ->get();
        return view('shop.product_details', compact('category', 'product', 'cartItems', 'wishlist', 'relatedProducts'));
    }
    /**
     * Show combo details.
     */
    public function showcombos($id)
    {
        $category = Category::all();
        $cartItems = CartItem::where('user_id', auth()->id())->get()->keyBy('product_id');
        $combo = Combo::with('category')->findOrFail($id);


        // Get wishlist from session
        $wishlist = session()->get('wishlist', []);



        return view('shop.combo_details', compact('category', 'combo', 'cartItems', 'wishlist'));
    }


    /**
     * Add product to the cart.
     */
    public function addToCart(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        // Get cart from session
        $cart = session('cart', []);

        // If product already exists in cart, update quantity
        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            // Add new product to the cart
            $cart[$id] = [
                'name' => $product->name,
                'price' => $product->price,
                'quantity' => 1,
                'image' => $product->image
            ];
        }

        // Store the updated cart in the session
        session(['cart' => $cart]);

        return redirect()->route('shop.index')->with('success', 'Product added to cart.');
    }

    /**
     * Update product quantity in the cart.
     */
    public function updateQuantity(Request $request, $id)
    {
        // Get the current cart from session
        $cart = session('cart', []);

        // If the product exists in the cart
        if (isset($cart[$id])) {
            // Update the quantity
            $cart[$id]['quantity'] = $request->quantity;

            // Store the updated cart in session
            session(['cart' => $cart]);
        }

        return redirect()->route('shop.index')->with('success', 'Cart updated successfully.');
    }

    /**
     * Remove product from the cart.
     */
    public function removeFromCart($id)
    {
        // Get the current cart from session
        $cart = session('cart', []);

        // If the product exists in the cart, remove it
        if (isset($cart[$id])) {
            unset($cart[$id]);
            session(['cart' => $cart]);
        }

        return redirect()->route('shop.index')->with('success', 'Product removed from cart.');
    }

    public function deleteAccount(Request $request)
    {
        $user = Auth::user();

        // Set the deletion time to 24 hours from now, if not already set
        if (!$user->deleted_at) {
            $user->deleted_at = Carbon::now('Asia/Kolkata')->addDay(); // 24 hours from now
            $user->save();
        }

        // Send the deletion notice email immediately
        try {
            Mail::to($user->email)->send(new AccountDeletionNotice($user));
        } catch (\Exception $e) {
            // If email fails, log the error
            Log::error('Email sending failed: ' . $e->getMessage());
        }

        // Dispatch the job to delete the account after 24 hours
        DeleteUserAccount::dispatch($user);

        // Log the user out
        Auth::logout();

        // Redirect to a confirmation page with a success message
        return redirect()->route('login')->with('success', 'Your account will be deleted in 24 hours. You have been logged out.');
    }

    public function showProfile()
    {
        // Return profile view with user data
        return view('user.show', ['user' => auth()->user()]);
    }

    public function showOrders()
    {
        // Assuming the user has orders related to them
        $orders = Order::where('user_id', auth()->id())->get();
        return view('user.orders', compact('orders'));
    }

    public function showOrderDetails($orderId)
    {
        // dd('dfgdf');
        $order = Order::with('order_items.product')->findOrFail($orderId);
        return view('user.myorder-details', compact('order'));
    }

    public function showWishlist()
    {
        // Get the product IDs from the session's wishlist
        $wishlist = session()->get('wishlist', []);

        // Fetch the products from the database based on the wishlist IDs
        $products = Product::whereIn('id', $wishlist)->get();

        // Pass the products to the view
        return view('shop.wishlist', compact('products'));
    }

    public function addWishlist(Product $product)
    {
        // Add product to session wishlist
        $wishlist = session()->get('wishlist', []);

        // If the product is already in the wishlist, do nothing
        if (!in_array($product->id, $wishlist)) {
            $wishlist[] = $product->id;
            session()->put('wishlist', $wishlist);
            return redirect()->back()->with('success', 'Product added to wishlist.');
        }

        return redirect()->back()->with('error', 'Product is already in your wishlist.');
    }

    public function removeWishlist(Product $product)
    {
        // Remove product from session wishlist
        $wishlist = session()->get('wishlist', []);

        // Remove the product by its ID
        if (($key = array_search($product->id, $wishlist)) !== false) {
            unset($wishlist[$key]);
            session()->put('wishlist', $wishlist);
            return redirect()->back()->with('success', 'Product removed from wishlist.');
        }

        return redirect()->back()->with('error', 'Product not found in wishlist.');
    }


    public function showSupport()
    {
        return view('user.support'); // Your Blade view for the support page
    }

    // Method to handle the support form submission
    public function storeSupport(Request $request)
    {
        // Validate the incoming message
        $request->validate([
            'message' => 'required|string|max:1000',
        ]);

        // Store the support request in the database
        SupportRequest::create([
            'user_id' => auth()->id(), // Get the logged-in user's ID
            'message' => $request->input('message'),
            'status' => 'pending', // Default status
        ]);

        // Redirect the user back with a success message
        return redirect()->route('user.support')->with('success', 'Your support request has been sent!');
    }
    public function showFAQ()
    {
        return view('user.faq');
    }

    public function Aboutus()
    {
        return view('user.about-us'); // Your Blade view for the support page
    }

    public function Blog()
    {
        return view('user.blog'); // Your Blade view for the support page
    }
}