<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class ChangePasswordController extends Controller
{
    public function showChangePasswordForm()
    {
        return view('auth.change-password');
    }
    // Show the change password form for user
    public function showuserChangePasswordForm()
    {
        return view('user.change-password');
    }

    // Update the user's password
    public function updatePassword(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'current_password' => 'required|string',  // Only required and must be a string
            'new_password' => [
                'required',
                'string',
                'min:8',
                'max:13',
                'confirmed',
                'regex:/[A-Z]/',  // At least one uppercase letter
                'regex:/[0-9]/',  // At least one number
                'regex:/[!@#$%^&*(),.?":{}|<>]/',  // At least one symbol
            ],
            'new_password_confirmation' => 'required|string',  // Confirmation field is required
        ], [
            'current_password.required' => 'The current password is required.',
            'current_password.string' => 'The current password must be a valid string.',
            'new_password.required' => 'The new password is required.',
            'new_password.string' => 'The new password must be a valid string.',
            'new_password.min' => 'The new password must be at least 8 characters.',
            'new_password.max' => 'The new password must not exceed 13 characters.',
            'new_password.confirmed' => 'The new password confirmation does not match.',
            'new_password.regex' => 'The new password must include at least one uppercase letter, one number, and one special character.',
            'new_password_confirmation.required' => 'Please confirm the new password.',
            'new_password_confirmation.string' => 'The password confirmation must be a valid string.',
        ]);

        $user = Auth::user();

        // Check if the current password matches the stored password
        if (!Hash::check($request->current_password, $user->password)) {
            throw ValidationException::withMessages([
                'current_password' => 'The current password is incorrect.',
            ]);
        }

        // Check if the new password is the same as the current password
        if ($request->current_password === $request->new_password) {
            throw ValidationException::withMessages([
                'new_password' => 'The new password cannot be the same as the current password.',
            ]);
        }

        // Update the user's password with the new hashed password
        $user->update([
            'password' => Hash::make($request->new_password),
        ]);

        // Log the user out after password change
        Auth::logout();

        // Redirect to the login page with a success message
        return redirect()->route('login')->with('success', 'Password changed successfully! Please log in again.');
    }
}