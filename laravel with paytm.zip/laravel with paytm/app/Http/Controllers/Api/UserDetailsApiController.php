<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Http\Controllers\Controller;

class UserDetailsApiController extends Controller
{
    public function index(Request $request)
    {
        $query = User::withoutTrashed();

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%')
                ->orWhere('email', 'like', '%' . $request->search . '%')
                ->orWhere('mobile_number', 'like', '%' . $request->search . '%');
        }

        return response()->json($query->get());
    }

    public function show($id)
    {
        $user = User::findOrFail($id);
        return response()->json($user);
    }

    // Create a new user
    public function create(Request $request)
    {
        $validated = $request->validate([
            'role' => 'required|in:admin,user',
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'mobile_number' => 'required|max:15',
            'password' => 'required|min:8',
        ]);

        $user = User::create([
            'role' => $validated['role'],
            'name' => $validated['name'],
            'email' => $validated['email'],
            'mobile_number' => $validated['mobile_number'],
            'password' => Hash::make($validated['password']),
        ]);

        return response()->json(['message' => 'User created successfully!', 'user' => $user]);
    }

    // Update an existing user
    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $validated = $request->validate([
            'role' => 'required|in:admin,user',
            'name' => 'sometimes|required|string|max:255',
            'email' => 'sometimes|required|email|unique:users,email,' . $user->id,
            'mobile_number' => 'sometimes|required|max:15',
            'password' => 'nullable|min:8',
        ]);

        if ($request->has('role')) {
            $user->role = $request->input('role');
        }
        if ($request->has('name')) {
            $user->name = $request->input('name');
        }
        if ($request->has('email')) {
            $user->email = $request->input('email');
        }
        if ($request->has('mobile_number')) {
            $user->mobile_number = $request->input('mobile_number');
        }
        if ($request->has('password') && $request->input('password') !== '') {
            $user->password = Hash::make($request->input('password'));
        }

        $user->save();

        return response()->json(['message' => 'User details updated successfully!']);
    }

    // Soft delete a user
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return response()->json(['message' => 'User soft deleted successfully!']);
    }

    // Restore a soft-deleted user
    public function restore($id)
    {
        $user = User::withTrashed()->findOrFail($id);
        $user->restore();

        return response()->json(['message' => 'User restored successfully!']);
    }

    // Permanently delete a user
    public function forceDelete($id)
    {
        $user = User::withTrashed()->findOrFail($id);
        $user->forceDelete();

        return response()->json(['message' => 'User permanently deleted!']);
    }

    // Soft delete a user account
    public function softDelete($id)
    {
        $user = User::findOrFail($id);
        $user->deleted_at = Carbon::now(); // Set the deleted_at timestamp
        $user->save();

        return response()->json(['message' => 'User account marked for deletion!']);
    }

    // Toggle the user's role
    public function toggleRole(User $user)
    {
        $user->role = ($user->role === 'admin') ? 'user' : 'admin';
        $user->save();

        return response()->json(['role' => $user->role]);
    }
}
