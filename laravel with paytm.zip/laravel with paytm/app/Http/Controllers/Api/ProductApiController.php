<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Subcategory;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\Writer\PngWriter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductApiController extends Controller
{
    /**
     * Display a listing of the products.
     */
    public function index(Request $request)
    {
        // Start with the base query to get products, including soft-deleted ones
        $query = Product::with(['category', 'subcategory'])->withoutTrashed();

        // Apply filters for search, category, and subcategory
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->filled('subcategory_id')) {
            $query->where('subcategory_id', $request->subcategory_id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Get paginated results
        $products = $query->paginate(10);

        return response()->json($products);
    }

    /**
     * Store a newly created product in storage.
     */
    public function store(Request $request)
    {
        // Validate the incoming data
        $validated = $request->validate([
            'name' => 'required|string|min:3|max:255',
            'description' => 'nullable|string|max:1000',
            'price' => 'required|numeric|min:0',
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'nullable|exists:subcategories,id',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
            'status' => 'required|in:active,inactive',
        ]);

        // Handle image upload if an image is provided
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('products', 'public');
        }

        // Create the product with the validated data
        $product = Product::create([
            'name' => $validated['name'],
            'description' => $validated['description'],
            'price' => $validated['price'],
            'category_id' => $validated['category_id'],
            'subcategory_id' => $validated['subcategory_id'],
            'image' => isset($imagePath) ? $imagePath : null,
            'status' => $validated['status'],
        ]);

        return response()->json([
            'message' => 'Product created successfully!',
            'product' => $product
        ], 201);
    }

    /**
     * Display the specified product.
     */
    public function show(Product $product)
    {
        // Load related category and subcategory
        $product->load(['category', 'subcategory']);

        return response()->json($product);
    }

    /**
     * Update the specified product in storage.
     */
    public function update(Request $request, Product $product)
    {
        // Validate input data
        $validated = $request->validate([
            'name' => 'required|string|min:3|max:255',
            'description' => 'nullable|string|max:1000',
            'price' => 'required|numeric|min:0',
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'nullable|exists:subcategories,id',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:10240',
            'status' => 'required|in:active,inactive',
        ]);

        // Handle image upload if new image is provided
        if ($request->hasFile('image')) {
            // Delete the old image if exists
            if ($product->image && Storage::exists('public/' . $product->image)) {
                Storage::delete('public/' . $product->image);
            }

            // Store the new image and update the validated data with the new image path
            $imagePath = $request->file('image')->store('products', 'public');
            $validated['image'] = $imagePath;
        }

        // Update the product with the validated data
        $product->update($validated);

        return response()->json([
            'message' => 'Product updated successfully!',
            'product' => $product
        ]);
    }

    /**
     * Soft delete the product.
     */
    public function destroy(Product $product)
    {
        // Soft delete the product
        $product->delete();

        return response()->json([
            'message' => 'Product deleted successfully!'
        ]);
    }

    /**
     * Restore a soft-deleted product.
     */
    public function restore($id)
    {
        // Find the product including soft-deleted ones
        $product = Product::withTrashed()->findOrFail($id);

        // Restore the product
        $product->restore();

        return response()->json([
            'message' => 'Product restored successfully!',
            'product' => $product
        ]);
    }

    /**
     * Update product status (active/inactive).
     */
    public function updateStatus(Product $product)
    {
        // Toggle the product status between active and inactive
        $product->status = $product->status === 'active' ? 'inactive' : 'active';
        $product->save();

        return response()->json([
            'message' => 'Product status updated successfully!',
            'status' => $product->status
        ]);
    }

    /**
     * Get subcategories of a category.
     */
    public function getSubcategories($categoryId)
    {
        // Fetch subcategories based on category ID
        $subcategories = Subcategory::where('category_id', $categoryId)->get();

        return response()->json($subcategories);
    }

    public function generateProductQrCode($productId)
    {
        try {
            // Fetch the product by its ID
            $product = Product::findOrFail($productId);

            // Check if the product has a valid category
            if (!$product->category) {
                return response()->json(['error' => 'Product category not found.'], 400);
            }

            // Prepare product data to include in the QR code
            $productData = sprintf(
                "Product Name: %s\nDescription: %s\nPrice: $%0.2f\nStatus: %s\nCategory: %s",
                $product->name,
                $product->description,
                $product->price,
                ucfirst($product->status),
                $product->category->name
            );

            // Return the product data as JSON
            return response()->json([
                'productData' => $productData
            ], 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            // Handle the case where the product is not found
            return response()->json(['error' => 'Product not found.'], 404);
        } catch (\Exception $e) {
            // General exception handler
            return response()->json(['error' => 'An error occurred while generating the QR code.'], 500);
        }
    }
}
