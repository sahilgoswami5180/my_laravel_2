<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    // Specify which attributes are mass assignable
    protected $fillable = [
        'order_id',
        'product_id',
        'product_name',
        'product_image',
        'quantity',
        'price',
        'user_id',  // Add user_id to fillable attributes
    ];

    /**
     * Get the order that owns the order item.
     */
    // In the OrderItem model
    public function order()
    {
        return $this->belongsTo(Order::class); // foreign key: order_id
    }

    /**
     * Get the product associated with the order item.
     */
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Get the user that owns the order item.
     */
    public function user()
    {
        return $this->belongsTo(User::class); // Add relationship with User model
    }
}
