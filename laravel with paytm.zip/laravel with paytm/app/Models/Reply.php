<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reply extends Model
{
    use HasFactory;

    protected $fillable = ['contact_us_id', 'message'];

    // Define the inverse of the relationship
    public function contactUs()
    {
        return $this->belongsTo(ContactUs::class);
    }
}
