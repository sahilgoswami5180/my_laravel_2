<?php $__env->startSection('content'); ?>
<div class="container mx-auto top-0">
    <!-- Breadcrumb Navigation -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('shop.combos')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Combos</a>
                </div>
            </li>
        </ol>
    </div>

    <!-- Combo Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 py-4">
        <?php $__currentLoopData = $combos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $isInCart = isset($cartItems[$combo->id]); // Check if the combo is in the cart
        ?>

        <!-- Combo Card -->
        <div class="relative bg-white rounded-lg shadow-lg overflow-hidden group transform transition-all duration-300">
            <!-- Combo Image Section -->
            <div class="w-full h-48 p-2">
                <img src="<?php echo e(asset('storage/' . $combo->image)); ?>" alt="<?php echo e($combo->name); ?>"
                    class="w-full h-full object-cover rounded-md mx-auto">
            </div>

            <!-- Combo Details -->
            <a href="<?php echo e(route('shop.combo_details', $combo->id)); ?>">
                <div class="px-4 pb-4 text-left relative">
                    <span
                        class="text-md font-semibold text-gray-800 mb-2 absolute -top-1 right-0 py-2 pr-4 pl-2 rounded-md transform">
                        <span class="text-xl">₹</span><?php echo e($combo->total_price); ?>

                    </span>
                    <h3 class="text-sm font-semibold text-gray-800 mb-2">
                        <?php echo e(Str::limit($combo->name, 55, '...')); ?>

                    </h3>

                    <p class="text-sm text-gray-700"><?php echo e(Str::limit($combo->description, 80, '...')); ?></p>
                    <p class="text-sm text-gray-700"><span class="text-green-800">Category:</span> <?php echo e($combo->category->name); ?></p>

                    <!-- Action Buttons (Add to Cart or Quantity Control) -->
                    <?php if($isInCart): ?>
                    <div class="mt-4 flex items-center justify-end">
                        <!-- Quantity Form (If it's in the cart) -->
                        <form action="<?php echo e(route('cart.updateQuantity', $cartItems[$combo->id])); ?>" method="POST"
                            class="inline-flex items-center space-x-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="flex space-x-2">
                                <button type="submit" name="quantity"
                                    value="<?php echo e($cartItems[$combo->id]['quantity'] - 1); ?>"
                                    class="bg-gray-300 text-gray-700 hover:bg-red-600 hover:text-red-200 px-4 py-2 rounded-md transition duration-300 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                                    <?php echo e($cartItems[$combo->id]['quantity'] <= 1 ? 'disabled' : ''); ?>>
                                        <i class="fas fa-minus text-gray-800"></i>
                                </button>

                                <button type="submit" name="quantity"
                                    value="<?php echo e($cartItems[$combo->id]['quantity'] + 1); ?>"
                                    class="bg-gray-300 text-gray-700 hover:bg-green-600 hover:text-green-100 px-4 py-2 rounded-md transition duration-300 flex items-center justify-center">
                                    <i class="fas fa-plus text-gray-800"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                    <?php else: ?>
                    <!-- Add to Cart Button (If it's not in the cart) -->
                    <div class="relative bottom-0 right-0 flex space-x-1 mt-6 mx-2 justify-end items-center">
                        <form action="<?php echo e(route('cart.add', $combo)); ?>" method="POST" class="w-auto">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full flex items-center justify-end border-2 border-blue-500 text-blue-600 p-2 rounded-xl font-medium hover:bg-blue-800 hover:text-white transition">
                                <i class="fas fa-shopping-bag text-xs"> ADD TO CART</i>
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/shop/combos.blade.php ENDPATH**/ ?>