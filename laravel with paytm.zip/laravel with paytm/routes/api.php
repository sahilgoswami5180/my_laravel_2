<?php

use App\Http\Controllers\Api\CategoryApiController;
use App\Http\Controllers\Api\ProductApiController;
use App\Http\Controllers\Api\UserDetailsApiController;

use Illuminate\Support\Facades\Route;

// Add middleware for authenticated routes (if applicable)

// Category Routes
Route::prefix('categories')->group(function () {
    Route::get('/', [CategoryApiController::class, 'index']);                  // GET /api/categories
    Route::post('/create', [CategoryApiController::class, 'store']);           // POST /api/categories/create
    Route::get('/{category}', [CategoryApiController::class, 'show']);         // GET /api/categories/{id}
    Route::put('/{category}', [CategoryApiController::class, 'update']);       // PUT /api/categories/{id}
    Route::delete('/delete/{category}', [CategoryApiController::class, 'destroy']); // DELETE /api/categories/delete/{id}
    Route::post('/{id}/restore', [CategoryApiController::class, 'restore']);  // POST /api/categories/{id}/restore
    Route::get('/{category}/products', [CategoryApiController::class, 'viewProducts']);  // GET /api/categories/{id}/products
    Route::get('/{category}/subcategories', [CategoryApiController::class, 'viewSubcategories']); // GET /api/categories/{id}/subcategories
});

// Product Routes
Route::prefix('products')->group(function () {
    Route::get('/', [ProductApiController::class, 'index']);                   // GET /api/products
    Route::post('/create', [ProductApiController::class, 'store']);            // POST /api/products/create
    Route::get('/{product}', [ProductApiController::class, 'show']);           // GET /api/products/{id}
    Route::put('/{product}', [ProductApiController::class, 'update']);         // PUT /api/products/{id}
    Route::delete('/{product}', [ProductApiController::class, 'destroy']);    // DELETE /api/products/{id}
    Route::post('/{id}/restore', [ProductApiController::class, 'restore']);   // POST /api/products/{id}/restore
    Route::post('/{product}/status', [ProductApiController::class, 'updateStatus']);  // POST /api/products/{id}/status
    Route::get('/{product}/generate-qrcode', [ProductApiController::class, 'generateProductQrCode']); // GET /api/products/{id}/generate-qrcode
    Route::get('/export/csv', [ProductApiController::class, 'exportToCsv']);  // GET /api/products/export/csv
    Route::get('/export/pdf', [ProductApiController::class, 'exportToPdf']);  // GET /api/products/export/pdf
    Route::get('/card', [ProductApiController::class, 'card']);               // GET /api/products/card
});




Route::get('/allusers', [UserDetailsApiController::class, 'index']);
Route::get('/users/{id}', [UserDetailsApiController::class, 'show']);
Route::post('/users', [UserDetailsApiController::class, 'create']);
Route::put('/users/update/{id}', [UserDetailsApiController::class, 'update']);
Route::delete('/users/delete/{id}', [UserDetailsApiController::class, 'destroy']);
Route::post('/users/{id}/restore', [UserDetailsApiController::class, 'restore']);
Route::delete('/users/{id}/force-delete', [UserDetailsApiController::class, 'forceDelete']);
Route::post('/users/{id}/soft-delete', [UserDetailsApiController::class, 'softDelete']);
Route::post('/users/{user}/toggle-role', [UserDetailsApiController::class, 'toggleRole']);


// Public Routes (if any, like for unauthenticated access to some resources)
// Example (unprotected routes)
Route::get('public/categories', [CategoryApiController::class, 'index']);   // Public GET /api/public/categories