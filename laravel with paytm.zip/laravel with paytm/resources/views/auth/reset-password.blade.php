<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce Shopping | Reset Password</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-4">Reset Password</h2>

        @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span>{{ session('success') }}</span>
        </div>

        <script>
            setTimeout(() => {
                    document.querySelector('#successToast').style.display = 'none';
                }, 4000);
        </script>
        @endif

        <!-- Error Toast -->
        @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Error Icon -->
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <!-- Error Message -->
            <span>{{ session('error') }}</span>
        </div>

        <script>
            setTimeout(() => {
                    document.querySelector('#errorToast').style.display = 'none';
                }, 4000);
        </script>
        @endif
        <form action="{{ route('auth.reset-password') }}" method="POST" class="space-y-4">
            @csrf

            <!-- Email Input -->
            <div>
                <label for="email" class="block text-gray-700 font-medium mb-1">Email Address <span
                        class="text-red-600">*</span></label>
                <input type="email" name="email" id="email"
                    class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your email" value="{{ old('email') }}">
                @error('email')
                <p class="text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Password Input -->
            <div>
                <label for="password" class="block text-gray-700 font-medium mb-1">New Password <span
                        class="text-red-600">*</span></label>
                <input type="password" name="password" id="password"
                    class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your new password">
                @error('password')
                <p class="text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Confirm Password Input -->
            <div>
                <label for="password_confirmation" class="block text-gray-700 font-medium mb-1">Confirm Password <span
                        class="text-red-600">*</span></label>
                <input type="password" name="password_confirmation" id="password_confirmation"
                    class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Confirm your new password">
                @error('password_confirmation')
                <p class="text-red-600 mt-1">{{ $message }}</p>
                @enderror
            </div>

            <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition">
                Reset Password
            </button>
        </form>
    </div>
</body>

</html>
