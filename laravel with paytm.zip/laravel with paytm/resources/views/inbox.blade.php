 @extends('layouts.app')

 @section('content')
     <div class="container w-full m-auto py-8 p-3">
         <!-- Heading and Action Buttons -->
         <div class="flex justify-between items-center mb-6">
             <h1 class="text-2xl font-semibold text-gray-800">Inbox</h1>
             <div class="flex space-x-4 ml-auto">
                 <!-- Mark All as Read Button with Tooltip -->
                 <form action="{{ route('contact-msg.mark-all-as-read') }}" method="POST" class="inline relative group">
                     @csrf
                     <button type="submit" class="text-blue-500 hover:text-blue-700">
                         <i class="fas fa-check-circle text-xl"></i>
                     </button>
                     <div
                         class="tooltip absolute left-1/2 transform -translate-x-1/2 bottom-12 bg-gray-800 text-white text-xs rounded-md py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                         Mark all as Read
                     </div>
                 </form>

                 <!-- Dropdown for Delete Options with Tooltip -->
                 <div class="relative group">
                     <button class="text-red-500 hover:text-red-700" id="deleteDropdownButton">
                         <i class="fas fa-trash-alt text-xl"></i>
                     </button>
                     <div id="deleteDropdownMenu"
                         class="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-md z-10 hidden">
                         <ul class="space-y-2">
                             <!-- Delete Selected Messages -->
                             <li>
                                 <form action="{{ route('contact-msg.delete-selected') }}" method="POST"
                                     id="deleteSelectedForm">
                                     @csrf
                                     @method('DELETE')
                                     <button type="submit"
                                         class="block text-sm text-red-500 hover:text-red-700 px-4 py-2 w-full text-left">
                                         Delete Selected Messages
                                     </button>
                                 </form>
                             </li>
                             <!-- Clear All Messages -->
                             <li>
                                 <form action="{{ route('contact-msg.clear-all') }}" method="POST" id="clearAllForm">
                                     @csrf
                                     @method('DELETE')
                                     <button type="submit"
                                         class="block text-sm text-red-500 hover:text-red-700 px-4 py-2 w-full text-left">
                                         Clear All Messages
                                     </button>
                                 </form>
                             </li>
                         </ul>
                     </div>

                     <div
                         class="tooltip absolute left-1/2 transform -translate-x-1/2 top-12 bg-gray-800 text-white text-xs rounded-md py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                         Delete Messages
                     </div>
                 </div>
             </div>
         </div>

         <!-- Unread and Read Messages Sections -->

         <div class="space-y-8">
             <!-- Unread Messages Section -->
             <div>
                 <div class="w-full bg-blue-400 p-4 rounded-t-md">
                     <h2 class="text-xl font-semibold text-white text-center flex items-center justify-center space-x-2">
                         <i class="fas fa-inbox text-blue-900 text-2xl"></i>
                         <span>Unread Messages</span>
                     </h2>
                     <p class="text-center text-sm text-gray-900 mt-2">You have unread messages from users. Review and take
                         action as needed.</p>
                 </div>

                 <ul class="space-y-4">
                     @foreach ($contactUsSubmissions->where('read', false) as $submission)
                         <li class="p-4 border-b border-gray-200 bg-white hover:bg-gray-50 transition-colors duration-200 ease-in-out rounded-md shadow-md message-item"
                             data-id="{{ $submission->id }}" ondblclick="toggleSelection(this)">

                             <div class="relative flex items-start space-x-3">
                                 <i class="fas fa-info-circle text-blue-500 text-xl"></i>
                                 <form action="{{ route('contact-msg.mark-as-read', $submission->id) }}" method="POST"
                                     class="absolute top-2 right-2">
                                     @csrf
                                     <button type="submit"
                                         class="text-sm bg-blue-500 hover:bg-blue-700 font-medium text-white p-2 rounded-lg">
                                         <i class="fas fa-check-circle mr-1"></i> Mark as Read
                                     </button>
                                 </form>
                             </div>

                             <div class="flex-1">
                                 <div class="flex justify-between items-center">
                                     <div class="flex space-x-4">
                                         <div class="flex items-center space-x-1">
                                             <i class="fas fa-user text-sm text-gray-500" style="font-size: 12px;"></i>
                                             <label class="font-semibold text-gray-500"
                                                 style="font-size: 12px;">Name:</label>
                                             <span class="text-gray-800">{{ $submission->name }}</span>
                                         </div>

                                         <div class="flex items-center space-x-1 ml-auto">
                                             <i class="fas fa-envelope text-sm text-gray-500" style="font-size: 12px;"></i>
                                             <label class="text-sm font-semibold text-gray-500"
                                                 style="font-size: 12px;">Email:</label>
                                             <span class="text-gray-500">{{ $submission->email }}</span>
                                         </div>
                                     </div>
                                 </div>

                                 <div class="mt-2">
                                     <label class="text-sm font-semibold text-gray-500"
                                         style="font-size: 12px;">Message:</label>
                                     <p class="text-sm text-gray-600 bg-gray-200 w-full h-10 px-2 py-1 rounded-lg mt-2">
                                         {{ Str::limit($submission->message, 80) }}
                                     </p>
                                 </div>





                                 <!-- Delete Button -->
                                 <div class="mt-4 flex justify-end space-x-4">
                                     <!-- Reply Section -->

                                     <button class="text-sm text-blue-500 hover:text-blue-700 font-medium reply-btn"
                                         data-id="{{ $submission->id }}">
                                         <i class="fas fa-reply mr-2"></i> Reply
                                     </button>

                                     <div class="reply-input-container hidden mt-2" id="replyInput-{{ $submission->id }}">
                                         <form action="{{ route('contact-msg.reply', $submission->id) }}" method="POST">
                                             @csrf
                                             <textarea class="w-full p-2 border border-gray-300 rounded-lg" placeholder="Write your reply..." name="message"
                                                 id="replyText-{{ $submission->id }}"></textarea>
                                             <button type="submit"
                                                 class="text-sm bg-blue-500 text-white hover:bg-blue-700 font-medium mt-2">
                                                 Send
                                             </button>
                                         </form>
                                     </div>

                                     <button class="text-sm text-red-500 hover:text-red-700 font-medium delete-btn"
                                         data-id="{{ $submission->id }}">
                                         <i class="fas fa-trash-alt mr-2"></i> Delete
                                     </button>
                                 </div>
                             </div>
                         </li>
                     @endforeach
                 </ul>
             </div>

             <!-- Read Messages Section -->
             <div>
                 <div class="w-full bg-blue-400 p-4 rounded-t-md">
                     <h2 class="text-xl font-semibold text-white text-center flex items-center justify-center space-x-2">
                         <i class="fas fa-envelope-open text-green-500 text-2xl"></i>
                         <span>Read Messages</span>
                     </h2>
                     <p class="text-center text-sm text-gray-900 mt-2">These messages have been reviewed. You can take
                         action
                         accordingly.</p>
                 </div>

                 <ul class="space-y-4">
                     @foreach ($contactUsSubmissions->where('read', true) as $submission)
                         <li class="p-4 border-b border-gray-200 bg-white hover:bg-gray-50 transition-colors duration-200 ease-in-out rounded-md shadow-sm message-item"
                             data-id="{{ $submission->id }}" ondblclick="toggleSelection(this)">

                             <div class="flex items-start space-x-3">
                                 <i class="fas fa-check-circle text-green-500 text-xl"></i>

                                 <div class="flex-1">
                                     <div class="flex justify-between items-center">
                                         <div class="flex space-x-4">
                                             <div class="flex items-center space-x-1">
                                                 <i class="fas fa-user text-sm text-gray-500"></i>
                                                 <label class="font-semibold text-gray-500">Name:</label>
                                                 <span class="text-gray-800">{{ $submission->name }}</span>
                                             </div>

                                             <div class="flex items-center space-x-1 ml-auto">
                                                 <i class="fas fa-envelope text-sm text-gray-500"></i>
                                                 <label class="font-semibold text-gray-500">Email:</label>
                                                 <span class="text-gray-500">{{ $submission->email }}</span>
                                             </div>
                                         </div>
                                     </div>

                                     <div class="mt-2">
                                         <label class="text-sm font-semibold text-gray-500">Message:</label>
                                         <p class="text-sm text-gray-600 bg-gray-100 p-2 rounded-lg mt-2">
                                             {{ Str::limit($submission->message, 80) }}
                                         </p>
                                     </div>

                                     <div class="mt-4 flex justify-end space-x-4">
                                         <button class="text-sm text-blue-500 hover:text-blue-700 font-medium reply-btn"
                                             data-id="{{ $submission->id }}">
                                             <i class="fas fa-reply mr-2"></i> Reply
                                         </button>
                                         <button class="text-sm text-red-500 hover:text-red-700 font-medium delete-btn"
                                             data-id="{{ $submission->id }}">
                                             <i class="fas fa-trash-alt mr-2"></i> Delete
                                         </button>
                                     </div>
                                 </div>
                             </div>
                         </li>
                     @endforeach
                 </ul>
             </div>
         </div>
     </div>

     <script>
         // Handle the visibility of the delete dropdown
         document.getElementById('deleteDropdownButton').addEventListener('click', function(event) {
             const dropdownMenu = document.getElementById('deleteDropdownMenu');

             // Toggle the 'hidden' class to show/hide the dropdown menu
             dropdownMenu.classList.toggle('hidden');

             // Prevent click event from bubbling up to avoid immediate close
             event.stopPropagation();
         });

         // Close the dropdown if clicked outside
         document.addEventListener('click', function(event) {
             const dropdownMenu = document.getElementById('deleteDropdownMenu');
             const dropdownButton = document.getElementById('deleteDropdownButton');

             // Close dropdown if clicked outside
             if (!dropdownButton.contains(event.target) && !dropdownMenu.contains(event.target)) {
                 dropdownMenu.classList.add('hidden');
             }
         });

         // Handle Reply Button
         document.querySelectorAll('.reply-btn').forEach(button => {
             button.addEventListener('click', function() {
                 const messageId = button.getAttribute('data-id');
                 const replyContainer = document.getElementById(`replyInput-${messageId}`);
                 replyContainer.classList.toggle('hidden');
             });
         });

         // Handle Delete Button for individual messages
         document.querySelectorAll('.delete-btn').forEach(button => {
             button.addEventListener('click', function() {
                 const messageId = button.getAttribute('data-id');
                 if (confirm("Are you sure you want to delete this message?")) {
                     fetch(`/contact-msg/delete/${messageId}`, {
                         method: 'DELETE',
                         headers: {
                             'Content-Type': 'application/json',
                             'X-CSRF-TOKEN': '{{ csrf_token() }}',
                         }
                     }).then(response => {
                         if (response.ok) {
                             window.location.reload();
                         }
                     });
                 }
             });
         });

         // Mark as Read
         document.querySelectorAll('.mark-as-read-btn').forEach(button => {
             button.addEventListener('click', function() {
                 const messageId = button.getAttribute('data-id');
                 fetch(`/contact-msg/${messageId}/read`, {
                     method: 'POST',
                     headers: {
                         'Content-Type': 'application/json',
                         'X-CSRF-TOKEN': '{{ csrf_token() }}',
                     }
                 }).then(response => {
                     if (response.ok) {
                         window.location.reload();
                     }
                 });
             });
         });
     </script>
 @endsection
