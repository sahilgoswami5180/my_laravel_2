@extends('layouts.user')

@section('title', 'E-commerce Shopping | Blogs')

@section('content')
<section id="page-header" class="blog-header" style="background-image: url('/img/banner/b19.jpg');">
    <h2>#readmore</h2>
    <p>Read all case studies about our products!</p>
</section>

<section id="blog">
    <div class="blog-box">
        <div class="blog-img">
            <img src="./img/blog/b1.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>The Cotton Jersey Zip-Up Hoodie</h4>
            <p>The Cotton Jersey Zip-Up Hoodie is a versatile and comfortable outerwear piece that combines style and
                functionality. Crafted from high-quality cotton jersey fabric, this hoodie offers a cozy feel and a
                casual yet fashionable look.</p>
            <a href="#">CONTINUE READING</a>
        </div>
        <h1>13/01</h1>
    </div>
    <div class="blog-box">
        <div class="blog-img">
            <img src="./img/blog/b2.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>How to Style a Quiff</h4>
            <p>The Quiff is a timeless and sophisticated hairstyle that never fails to make a statement. With its
                voluminous and sculpted front, it adds a touch of elegance and charm to any look.</p>
            <a href="#">CONTINUE READING</a>
        </div>
        <h1>13/04</h1>
    </div>
    <div class="blog-box">
        <div class="blog-img">
            <img src="./img/blog/b3.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>Must-Have Skater Girl Items</h4>
            <p>Must-Have Skater Girl Items are essential for adding a cool and edgy vibe to your wardrobe. From
                skateboard to streetwear, these items perfectly capture the skater girl aesthetic.</p>
            <a href="#">CONTINUE READING</a>
        </div>
        <h1>12/01</h1>
    </div>
    <div class="blog-box">
        <div class="blog-img">
            <img src="./img/blog/b4.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>Runway-Inspired Trends</h4>
            <p>Runway-Inspired Trends are the ultimate source of fashion inspiration, bringing high-end style to
                everyday life. From bold prints to statement accessories, these trends allow you to express your
                creativity and stay ahead of the fashion curve.</p>
            <a href="#">CONTINUE READING</a>
        </div>
        <h1>16/01</h1>
    </div>
    <div class="blog-box">
        <div class="blog-img">
            <img src="./img/blog/b6.jpg" alt="">
        </div>
        <div class="blog-details">
            <h4>AW20 Menswear Trends</h4>
            <p>AW20 Menswear Trends are all about blending sophistication with a touch of rebellion. From tailored
                outerwear to statement accessories, these trends offer a contemporary and stylish approach to men's
                fashion.</p>
            <a href="#">CONTINUE READING</a>
        </div>
        <h1>10/03</h1>
    </div>
</section>

<section id="pagination" class="section-p1">
    <a href="#">1</a>
    <a href="#">2</a>
    <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
</section>

<section id="newsletter" class="section-p1 section-m1">
    <div class="newstext">
        <h4>Sign Up For Newsletters</h4>
        <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
    </div>
    <div class="form">
        <input type="text" placeholder="Your email address">
        <button class="normal">Sign Up</button>
    </div>
</section>
@endsection
