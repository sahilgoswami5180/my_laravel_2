@extends('layouts.user')

@section('content')
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">Support / Need Help?</h2>

            <p class="text-center text-gray-700 mb-6">
                If you need assistance, please reach out to our support team. We are here to help you with any issues you
                may have.
            </p>

            <!-- Success Message -->
            @if (session('success'))
                <div class="bg-green-500 text-white p-4 rounded-lg mb-6 text-center">
                    {{ session('success') }}
                </div>
            @endif

            <!-- Error Message (if validation fails) -->
            @if ($errors->any())
                <div class="bg-red-500 text-white p-4 rounded-lg mb-6 text-center">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <!-- Support Form -->
            <div class="mt-6">
                <form action="{{ route('user.support.store') }}" method="POST">
                    @csrf
                    <textarea name="message" rows="4" class="w-full p-3 border border-gray-300 rounded-lg"
                        placeholder="Describe your issue..." required></textarea>
                    <button type="submit"
                        class="w-full bg-indigo-500 text-white px-6 py-3 rounded-lg mt-4 hover:bg-indigo-600 transition">
                        Send Message
                    </button>
                </form>
            </div>
        </div>
    </div>
@endsection
