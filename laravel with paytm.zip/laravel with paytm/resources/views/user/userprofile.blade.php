@extends('layouts.user')

@section('content')
    <div class="min-h-96 mt-4 flex items-center justify-center bg-gray-50">
        <div class="bg-white shadow-lg rounded-lg px-4 w-full lg:w-10/12 xl:w-9/12 2xl:w-7/12 flex flex-col lg:flex-row p-8">
            <!-- Left Section: Profile Image and User Details -->
            <div class="lg:w-1/2 w-full px-4 lg:mb-0">
                <!-- Profile Image Update Form -->
                <form action="{{ route('profile.update.userimage') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <!-- Merged Image Preview and File Input -->
                    <div class="relative flex justify-center mb-1">
                        <!-- Profile Image Preview -->
                        <img id="profileImagePreview"
                            src="{{ asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png')) }}"
                            alt="Profile Picture"
                            class="w-32 h-32 rounded-full object-cover border-4 border-indigo-500 shadow-lg cursor-pointer mb-4">

                        <!-- Hidden File Input for Image Upload -->
                        <input type="file" name="profile_image" id="profile_image"
                            class="absolute inset-0 w-full h-full opacity-0 cursor-pointer rounded-full"
                            onchange="previewImage(event)" accept="image/*">

                        <!-- Pencil Icon Positioned at the Bottom-Right -->
                        <label for="profile_image" class="absolute bottom-0 bg-slate-500 rounded-lg p-1 cursor-pointer"
                            style="right: 200px;">
                            <i class="fa-solid fa-pencil text-white hover:text-indigo-700 text-xl"></i>
                        </label>
                    </div>

                    @error('profile_image')
                        <div class="text-red-500 text-sm text-center mt-2">{{ $message }}</div>
                    @enderror

                    <!-- Submit Button -->
                    <div class="text-center">
                        <button id="updateButton" type="submit"
                            class="w-full md:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out hidden">
                            Update Profile Image
                        </button>
                    </div>
                </form>

                <!-- User Details -->
                <div class="space-y-6 mt-6">
                    <!-- Name Section -->
                    <div class="flex justify-between items-center mb-4">
                        <label for="name" class="text-gray-700 font-medium">Name</label>
                        <div class="text-gray-800 bg-gray-200 p-2 rounded-lg">{{ $user->name }}</div>
                    </div>

                    <!-- Email Section -->
                    <div class="flex justify-between items-center mb-4">
                        <label for="email" class="text-gray-700 font-medium">Email</label>
                        <div class="text-gray-800 bg-gray-200 p-2 rounded-lg pr-10">{{ $user->email }}</div>
                    </div>

                    <!-- Joined Date Section -->
                    <div class="flex justify-between items-center mb-4">
                        <label for="created_at" class="text-gray-700 font-medium">Joined</label>
                        <div class="text-gray-800 bg-gray-200 p-2 rounded-lg pr-10">
                            {{ $user->created_at->format('F j, Y') }}</div>
                    </div>
                </div>
            </div>

            <!-- Right Section: Navigation Links and Action Buttons -->
            <div class="w-full lg:w-1/2 space-y-6">
                <h3 class="text-black text-2xl font-semibold">Account Management</h3>

                <!-- Navigation Links with Icons - Flex Column Layout -->
                <div class="w-full flex flex-col md:flex-row gap-6">
                    <!-- My Orders -->
                    <div
                        class="bg-indigo-100 p-4 rounded-lg shadow-lg flex items-center justify-center space-x-2 w-full sm:w-1/2 md:w-1/2 lg:w-1/2">
                        <i class="fas fa-box-open text-indigo-500 text-2xl hover:text-blue-800"></i>
                        <a href="{{ route('user.orders') }}" class="text-indigo-500 font-semibold hover:text-blue-800">My
                            Orders</a>
                    </div>
                    <!-- My Wishlist -->
                    <div
                        class="bg-indigo-100 p-4 rounded-lg shadow-lg flex items-center justify-center space-x-2 w-full sm:w-1/2 md:w-1/2 lg:w-1/2">
                        <i class="fas fa-heart text-indigo-500 text-2xl hover:text-blue-800"></i>
                        <a href="{{ route('shop.wishlist') }}" class="text-indigo-500 font-semibold hover:text-blue-800">My
                            Wishlist</a>
                    </div>
                </div>

                <!-- Second row of items -->
                <div class="flex flex-col lg:flex-row gap-6">
                    <!-- Support / Need Help -->
                    <div
                        class="bg-indigo-100 p-4 rounded-lg shadow-lg flex items-center justify-center space-x-2 w-full sm:w-1/2 md:w-1/2 lg:w-1/2">
                        <i class="fas fa-headset text-indigo-500 text-2xl hover:text-blue-800"></i>
                        <a href="{{ route('user.contact-us') }}"
                            class="text-indigo-500 font-semibold hover:text-blue-800">Support / Need Help?</a>
                    </div>
                    <!-- FAQ -->
                    <div
                        class="bg-indigo-100 p-4 rounded-lg shadow-lg flex items-center justify-center space-x-2 w-full sm:w-1/2 md:w-1/2 lg:w-1/2">
                        <i class="fas fa-question-circle text-indigo-500 text-2xl hover:text-blue-800"></i>
                        <a href="{{ route('user.faq') }}" class="text-indigo-500 font-semibold hover:text-blue-800">FAQ</a>
                    </div>
                </div>

                <!-- Action Buttons (Aligned Vertically) -->
                <div class="flex flex-col w-full gap-4">
                    <!-- Change Password Button -->
                    <a href="{{ route('userchange-password.form') }}"
                        class="w-full sm:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out">
                        <i class="fas fa-key mr-2"></i> Change Password
                    </a>

                    <!-- Delete Account Button -->
                    <button id="deleteAccountButton"
                        class="w-full sm:w-auto bg-red-500 text-white px-6 py-3 rounded-lg text-center hover:bg-red-600 transition duration-300 ease-in-out">
                        <i class="fas fa-trash-alt mr-2"></i> Delete Account
                    </button>
                </div>

            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <div id="confirmationModal" class="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg w-96">
            <h3 class="text-2xl font-semibold text-gray-800 mb-4">Are you sure you want to delete your account?</h3>
            <p class="text-gray-600 mb-4">This action cannot be undone. In 24 hours, your account and all associated data
                will be permanently deleted.</p>

            <!-- Action Buttons -->
            <div class="flex justify-between gap-4">
                <button id="cancelButton"
                    class="w-full md:w-auto bg-gray-300 text-gray-700 px-6 py-3 rounded-lg text-center hover:bg-gray-400 transition duration-300 ease-in-out">
                    Cancel
                </button>
                <form action="{{ route('delete.account') }}" method="POST">
                    @csrf
                    <button type="submit" id="confirmDeleteButton"
                        class="w-full md:w-auto bg-red-500 text-white px-6 py-3 rounded-lg text-center hover:bg-red-600 transition duration-300 ease-in-out">
                        Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Function to preview the selected image and show the update button
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                const preview = document.getElementById('profileImagePreview');
                preview.src = e.target.result; // Set the source to the selected file's data URL
            }

            if (file) {
                reader.readAsDataURL(file); // Read the file as a Data URL
                // Show the update button when an image is selected
                document.getElementById('updateButton').classList.remove('hidden');
            } else {
                // If no file is selected, keep the button hidden
                document.getElementById('updateButton').classList.add('hidden');
            }
        }

        // Show the confirmation modal when the user clicks "Delete Account"
        document.getElementById('deleteAccountButton').addEventListener('click', function() {
            document.getElementById('confirmationModal').classList.remove('hidden');
        });

        // Hide the confirmation modal when the user clicks "Cancel"
        document.getElementById('cancelButton').addEventListener('click', function() {
            document.getElementById('confirmationModal').classList.add('hidden');
        });
    </script>
@endsection
