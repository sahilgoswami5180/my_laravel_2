@extends('layouts.app')

@section('content')
    <div class="container mx-auto mt-0">
        <!-- Breadcrumb Navigation -->
        <nav class="flex text-sm text-gray-600 mb-2 items-center justify-between">
            <div class="flex items-center">
                <a href="{{ route('dashboard') }}"
                    class="hover:text-blue-500 flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <a href="{{ route('subcategories.index') }}"
                    class="hover:text-blue-500 flex items-center {{ Request::is('subcategories') || Request::is('subcategories/*') ? 'text-blue-500' : '' }}">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Subcategories</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Deleted Subcategories</span>
            </div>

            <!-- Button to Go Back to Subcategories -->
            <div class="flex items-center">
                <a href="{{ route('subcategories.index') }}"
                    class="bg-blue-500 text-white px-4 py-2 rounded-full shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300">
                    Back to Subcategories
                </a>
            </div>
        </nav>

        <!-- Table to display deleted subcategories -->
        <div class="overflow-x-auto bg-white rounded-lg shadow-xl mt-6">
            <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 text-gray-600">
                    <tr>
                        <th class="px-6 py-3 text-center text-md font-bold">ID</th>
                        <th class="px-6 py-3 text-center text-md font-bold">Subcategory Name</th>
                        <th class="px-6 py-3 text-center text-md font-bold">Deleted At</th>
                        <th class="px-6 py-3 text-center text-md font-bold">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @foreach ($deletedSubcategories as $subcategory)
                        <tr class="hover:bg-gray-50 transition-colors text-center duration-200">
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $subcategory->id }}</td>
                            <td class="px-6 py-4 text-sm text-gray-800">{{ $subcategory->name }}</td>
                            <td class="px-6 py-4 text-sm text-gray-800">
                                {{ $subcategory->deleted_at->format('Y-m-d H:i:s') }}</td>
                            <td class="px-6 py-4 text-sm text-center">
                                <div class="flex justify-center space-x-2">
                                    <!-- Restore Button -->
                                    <button type="button"
                                        class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition duration-300 flex items-center space-x-2"
                                        onclick="openRestoreModal({{ $subcategory->id }})">
                                        <i class="fas fa-undo"></i> Restore
                                    </button>

                                    <!-- Delete Permanently Button -->
                                    <button type="button"
                                        class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 flex items-center space-x-2"
                                        onclick="openDeleteModal({{ $subcategory->id }})">
                                        <i class="fas fa-trash-alt"></i> Delete Permanently
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- No Deleted Subcategories Found Message -->
        @if ($deletedSubcategories->isEmpty())
            <div class="mt-8 text-center text-gray-500">
                <p>No deleted subcategories found.</p>
            </div>
        @endif
    </div>

    <!-- Restore Confirmation Modal -->
    <div id="restoreModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-xl shadow-xl max-w-lg w-full">
            <div class="text-center mb-4">
                <div class="flex items-center justify-center mb-4">
                    <i class="fas fa-undo text-yellow-500 text-4xl mr-3"></i>
                    <h2 class="text-2xl font-semibold text-gray-800">Are you sure you want to restore this subcategory?</h2>
                </div>
            </div>
            <div class="flex justify-end gap-2">
                <button onclick="closeRestoreModal()"
                    class="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-times-circle"></i>
                    <span>Cancel</span>
                </button>
                <form id="restoreForm" method="POST" class="inline w-32">
                    @csrf
                    <input type="hidden" id="subcategoryId" name="subcategoryId">
                    <button type="submit"
                        class="bg-yellow-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 w-full flex items-center justify-center space-x-2">
                        <i class="fas fa-check-circle"></i>
                        <span>Restore</span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Permanently Confirmation Modal (Step 1) -->
    <div id="deleteModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-4 rounded-xl shadow-xl max-w-lg w-full">
            <div class="text-center mb-4">
                <div class="flex items-center justify-center mb-4">
                    <i class="fas fa-trash-alt text-red-500 text-4xl mr-3"></i>
                    <h2 class="text-2xl font-semibold text-gray-800">Are you sure you want to delete this subcategory
                        permanently?</h2>
                </div>
            </div>
            <p class="text-gray-600 text-lg text-center mb-6">This action is irreversible, and the subcategory will be
                permanently deleted from the system.</p>
            <div class="flex justify-end gap-2">
                <button onclick="closeDeleteModal()"
                    class="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-times-circle"></i>
                    <span>Cancel</span>
                </button>
                <button onclick="showSecondDeleteStep()"
                    class="bg-red-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-check-circle"></i>
                    <span>Confirm</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Delete Permanently Confirmation Modal (Step 2) -->
    <div id="secondDeleteModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-4 rounded-xl shadow-xl max-w-lg w-full">
            <div class="text-center mb-4">
                <i class="fas fa-trash-alt text-red-500 text-4xl mb-3"></i>
                <h2 class="text-2xl font-semibold text-gray-800">Are you really sure?</h2>
            </div>
            <p class="text-gray-600 text-lg text-center mb-6">This action cannot be undone. The subcategory will be
                permanently removed from your database.</p>
            <div class="flex justify-end gap-2">
                <button onclick="closeSecondDeleteModal()"
                    class="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition duration-300 w-32 flex items-center justify-center space-x-2">
                    <i class="fas fa-times-circle"></i>
                    <span>Cancel</span>
                </button>
                <form id="deleteForm" method="POST" class="inline w-32">
                    @csrf
                    @method('DELETE')
                    <button type="submit"
                        class="bg-red-500 text-white px-6 py-3 rounded-lg shadow-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 transition duration-300 w-full flex items-center justify-center space-x-2">
                        <i class="fas fa-trash-alt"></i>
                        <span>Delete Permanently</span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span>{{ session('success') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <!-- Error Toast -->
    @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Error Icon -->
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <!-- Error Message -->
            <span>{{ session('error') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <script>
        // Open Restore Modal
        function openRestoreModal(subcategoryId) {
            document.getElementById('subcategoryId').value = subcategoryId;
            // Dynamically set the restore form action for subcategories
            document.getElementById('restoreForm').action = '{{ route('subcategories.restore', ':id') }}'.replace(':id',
                subcategoryId);
            document.getElementById('restoreModal').classList.remove('hidden');
        }

        // Close Restore Modal
        function closeRestoreModal() {
            document.getElementById('restoreModal').classList.add('hidden');
        }

        // Open Delete Modal
        function openDeleteModal(subcategoryId) {
            // Dynamically set the form action for force deleting subcategories
            const deleteUrl = '{{ route('subcategories.force-delete', ':id') }}'.replace(':id', subcategoryId);
            document.getElementById('deleteForm').action = deleteUrl;
            document.getElementById('deleteModal').classList.remove('hidden');
        }

        // Close Delete Modal
        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.add('hidden');
        }

        // Step 2 of Delete
        function showSecondDeleteStep() {
            document.getElementById('deleteModal').classList.add('hidden');
            document.getElementById('secondDeleteModal').classList.remove('hidden');
        }

        // Close Step 2 of Delete
        function closeSecondDeleteModal() {
            document.getElementById('secondDeleteModal').classList.add('hidden');
        }
    </script>
@endsection
