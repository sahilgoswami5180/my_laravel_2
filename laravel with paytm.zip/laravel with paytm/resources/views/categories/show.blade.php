@extends('layouts.app')

@section('title', 'Category Details')

@section('content')
    <div class="container mx-auto mt-8">

        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">

                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('categories.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Categories</a>
                    </div>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('categories.create') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Create
                            Category</a>
                    </div>
                </li>

                <!-- Current Page -->
                <li aria-current="page">
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Create
                            Category</span>
                    </div>
                </li>
            </ol>
        </div>


        <!-- Category Details Card Container -->
        <div class="flex flex-col md:flex-row gap-6 max-w-4xl mx-auto">

            <!-- Image Section (Left Side) -->
            <div class="w-full md:w-1/3 bg-white rounded-lg shadow-lg overflow-hidden">
                @if ($category->image)
                    <img src="{{ asset('storage/' . $category->image) }}" alt="{{ $category->name }}"
                        class="w-full h-64 object-cover">
                @else
                    <div class="w-full h-64 bg-gray-200 flex items-center justify-center text-gray-500">
                        No Image Available
                    </div>
                @endif
            </div>

            <!-- Details Section (Right Side) -->
            <div class="w-full md:w-2/3 bg-white rounded-lg shadow-lg p-6">
                <!-- Category Name -->
                <h1 class="text-3xl font-semibold text-gray-800 mb-4">{{ $category->name }}</h1>

                <!-- Category Description -->
                <p class="text-lg text-gray-600 mb-6">
                    {{ $category->description ?: 'No description provided.' }}
                </p>

                <!-- Subcategories as Tags -->
                @if ($category->subcategories->count() > 0)
                    <div class="mt-4">
                        <h3 class="text-lg font-medium text-gray-700">Subcategories</h3>
                        <div class="mt-2 flex flex-wrap gap-2">
                            @foreach ($category->subcategories as $subcategory)
                                <a href="{{ route('subcategories.show', $subcategory->id) }}"
                                    class="bg-blue-500 text-white text-sm px-4 py-2 rounded-md hover:bg-blue-600 cursor-pointer uppercase">
                                    {{ $subcategory->name }}
                                </a>
                            @endforeach
                        </div>
                    </div>
                @else
                    <div class="mt-4">
                        <span class="text-sm text-gray-500">No subcategories available.</span>
                    </div>
                @endif

                <!-- Action Buttons -->
                <div class="flex gap-4 mt-6">


                    <!-- Edit Button -->
                    <a href="{{ route('categories.edit', $category) }}"
                        class="bg-yellow-500 text-white px-6 py-3 rounded-lg hover:bg-yellow-600 transition duration-300 flex items-center justify-center">
                        <i class="fas fa-edit mr-2"></i> <span>Edit</span>
                    </a>

                    <!-- Delete Button -->
                    <button type="button"
                        class="bg-red-500 text-white px-6 py-3 rounded-lg hover:bg-red-600 transition duration-300 flex items-center justify-center"
                        onclick="openDeleteModal({{ $category->id }})">
                        <i class="fas fa-trash-alt mr-2"></i> <span>Delete</span>
                    </button>
                </div>
            </div>

        </div>

        <!-- Delete Confirmation Modal -->
        <div id="deleteModal" class="fixed inset-0 bg-gray-500 bg-opacity-50 flex justify-center items-center z-50 hidden">
            <div class="bg-white p-6 rounded-lg shadow-lg w-1/3">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Are you sure you want to delete this category?</h3>
                <div class="flex justify-end space-x-4">
                    <button type="button" class="bg-gray-300 text-gray-800 px-4 py-2 rounded"
                        onclick="closeDeleteModal()">Cancel</button>
                    <form id="deleteForm" method="POST" class="inline-block">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded">Delete</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <!-- Success Toast -->
    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span>{{ session('success') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <!-- Error Toast -->
    @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span>{{ session('error') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <script>
        let deleteModal = document.getElementById('deleteModal');
        let deleteForm = document.getElementById('deleteForm');

        function openDeleteModal(categoryId) {
            // Set the action URL of the delete form to the correct route
            deleteForm.action = `/categories/${categoryId}`;

            // Show the modal
            deleteModal.classList.remove('hidden');
        }

        function closeDeleteModal() {
            // Hide the modal
            deleteModal.classList.add('hidden');
        }
    </script>
@endsection
