@extends('layouts.user')

@section('content')
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Wishlist</h2>

            @if (!$products)
                <!-- Empty Wishlist Card -->
                <div class="bg-gray-100 p-6 rounded-lg shadow-md text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                        class="mx-auto w-20 h-20 text-gray-400 mb-4">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 19V6l-3 3m0 0L9 6m0 0l3 3m9 7h-4l-1-3h-5l-1 3H4m16 0c0 1.104-.896 2-2 2H6c-1.104 0-2-.896-2-2V8c0-1.104.896-2 2-2h12c1.104 0 2 .896 2 2v11z" />
                    </svg>
                    <p class="text-lg text-gray-600 mb-2">Your wishlist is currently empty.</p>
                    <p class="text-gray-500 mb-4">Start adding your favorite items to the wishlist and they will appear
                        here.</p>
                    <a href="{{ route('shop.index') }}"
                        class="inline-block bg-blue-600 text-white py-2 px-6 rounded-full hover:bg-blue-700 transition duration-200">
                        Browse Products
                    </a>
                </div>
            @else
                <!-- Display Wishlist Products -->
                <ul class="space-y-4">
                    @foreach ($products as $product)
                        <li class="flex flex-wrap items-center border-b border-gray-200 py-4">
                            <!-- Product Image (Smaller Version) -->
                            <img src="{{ asset('storage/' . explode(',', $product->images)[0]) }}"
                                alt="{{ $product->name }}" class="w-24 h-24 object-cover rounded-md mr-4">

                            <!-- Product Name and Price -->
                            <div class="flex-1">
                                <span class="text-gray-700 font-semibold block">{{ $product->name }}</span>
                                <span class="text-gray-500">${{ number_format($product->price, 2) }}</span>
                            </div>

                            <!-- Remove from Wishlist Button -->
                            <form action="{{ route('wishlist.remove', $product->id) }}" method="POST" class="ml-4">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                    class="text-red-500 hover:text-red-700 border-2 border-red-500 hover:border-red-700 hover:bg-red-100 hover:text-red-800 rounded-lg p-1 focus:outline-none">
                                    Remove
                                </button>
                            </form>
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
@endsection
