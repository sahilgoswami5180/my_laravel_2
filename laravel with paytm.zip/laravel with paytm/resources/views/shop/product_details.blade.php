@extends('layouts.user')

@section('title', 'E-commerce Shopping | Product Details')

@section('content')
<!-- Back Icon -->
<section class="py-8 bg-gradient-to-r from-blue-50 to-gray-100 shadow-md">
    <!-- Breadcrumb Navigation -->
    <nav class="w-full bg-white shadow-md py-4 -mt-9 mb-6 rounded-lg px-6 md:px-12" aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="{{ url('/') }}"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-primary-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="me-2.5 h-3 w-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <!-- Products Breadcrumb -->
            <li>
                <div class="flex items-center">
                    <svg class="h-5 w-5 text-gray-400 rtl:rotate-180" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m9 5 7 7-7 7" />
                    </svg>
                    <a href="{{ route('shop.index') }}"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-primary-600 dark:text-gray-400 dark:hover:text-white md:ms-2">Products</a>
                </div>
            </li>
            <!-- Current Product Breadcrumb -->
            <li aria-current="page">
                <div class="flex items-center">
                    <svg class="h-5 w-5 text-gray-400 rtl:rotate-180" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m9 5 7 7-7 7" />
                    </svg>
                    <span class="ms-1 text-sm font-medium text-gray-500 dark:text-gray-400 md:ms-2">{{ $product->name
                        }}</span>
                </div>
            </li>
        </ol>
    </nav>


    <div class="container mx-auto py-2 px-4">
        <div class="flex flex-col lg:flex-row lg:gap-24">

            <!-- Product Image Carousel -->
            <div class="lg:w-5/12 flex justify-center lg:flex-col lg:items-center">
                <div class="relative flex flex-col lg:flex-row items-start">
                    @php
                    $images = explode(',', $product->images); // Assuming images are stored as comma-separated string
                    @endphp

                    @if (count($images) > 0)
                    <!-- Thumbnail Images -->
                    <div id="thumbnails"
                        class="overflow-y-auto max-h-80 scrollbar-custom lg:w-1/4 flex lg:flex-col space-y-2">
                        @foreach ($images as $index => $image)
                        <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                            class="thumbnail w-20 h-36 object-cover cursor-pointer transition-transform duration-300 hover:scale-105"
                            data-image="{{ asset('storage/' . $image) }}" />
                        @endforeach
                    </div>

                    <!-- Big Image -->
                    <div id="big-image-container" class="mb-4 lg:ml-4 lg:w-3/4">
                        <img id="big-image" src="{{ asset('storage/' . $images[0]) }}" alt="{{ $product->name }}"
                            class="zoom-image h-96 object-contain rounded-lg shadow-xl cursor-pointer transition-transform duration-500 hover:scale-105"
                            style="width: 580px;" />
                    </div>
                    @else
                    <img src="{{ asset('images/placeholder.png') }}" alt="{{ $product->name }}"
                        class="w-full h-auto object-cover rounded-md cursor-pointer" />
                    @endif
                </div>
            </div>

            <!-- Product Info -->
            <div class="lg:w-7/12 flex flex-col space-y-6">
                <p class="text-xl font-semibold text-gray-800 hover:text-blue-600 transition-colors duration-300">
                    {{ $product->name }}
                </p>
                <p class="text-sm text-gray-500">Category: <span class="text-gray-700 font-semibold">{{
                        $product->category->name }}</span></p>
                <p class="text-xs text-gray-600 mt-4 leading-relaxed">{{ $product->description }}</p>

                <p class="text-xl font-bold text-gray-800">₹{{ number_format($product->price, 2) }}</p>

                <!-- Add to Cart and Wishlist Buttons -->
                <div class="mt-6 grid grid-cols-1 gap-4">
                    <div class="flex items-center justify-between border p-4 rounded-lg shadow-md bg-white">
                        <div class="flex space-x-4 w-full">
                            <!-- Adjust space for mobile -->

                            <!-- Add to Wishlist Button -->
                            @php
                            $isInWishlist = in_array($product->id, session('wishlist', []));
                            @endphp
                            <form
                                action="{{ $isInWishlist ? route('wishlist.remove', $product) : route('wishlist.add', $product) }}"
                                method="POST" class="flex-1">
                                @csrf
                                @if ($isInWishlist)
                                @method('DELETE')
                                @endif
                                <button type="submit"
                                    class="w-full flex items-center justify-center bg-transparent border-2 px-3 py-2 rounded-md transition-all duration-300 {{ $isInWishlist ? 'text-red-500 border-red-500' : 'text-gray-700 border-gray-300' }}">
                                    <i
                                        class="bx {{ $isInWishlist ? 'bxs-heart text-red-500' : 'bx-heart text-gray-300' }} text-2xl mr-2"></i>
                                    <span class="hidden sm:inline">{{ $isInWishlist ? 'Unsave' : 'Save' }}</span>
                                </button>
                            </form>

                            <!-- Add to Cart / Quantity Controls -->
                            @php
                            $isInCart = isset($cartItems[$product->id]);
                            @endphp

                            @if ($isInCart)
                            <!-- Quantity Controls for items in the cart -->
                            <div class="flex items-center space-x-4">
                                <form action="{{ route('cart.updateQuantity', $product) }}" method="POST"
                                    class="inline-flex items-center space-x-3">
                                    @csrf
                                    @method('PATCH')
                                    <span class="bg-gray-100 rounded-md text-lg font-semibold p-3 w-12 text-center">{{
                                        $cartItems[$product->id]['quantity'] }}</span>
                                    <div class="flex space-x-2">
                                        <!-- Minus Button -->
                                        <button type="submit" name="quantity"
                                            value="{{ $cartItems[$product->id]['quantity'] - 1 }}"
                                            class="bg-gray-300 text-gray-700 hover:bg-gray-400 px-4 py-2 rounded-md transition duration-300 {{ $cartItems[$product->id]['quantity'] <= 1 ? 'opacity-50 cursor-not-allowed' : '' }}"
                                            {{ $cartItems[$product->id]['quantity'] <= 1 ? 'disabled' : '' }}>
                                                <i class="fas fa-minus"></i>
                                        </button>
                                        <!-- Plus Button -->
                                        <button type="submit" name="quantity"
                                            value="{{ $cartItems[$product->id]['quantity'] + 1 }}"
                                            class="bg-gray-300 text-gray-700 hover:bg-gray-400 px-4 py-2 rounded-md transition duration-300">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </form>
                                <!-- Remove Button -->
                                <form action="{{ route('cart.remove', $product) }}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                        class="text-red-500 border-2 border-red-500 hover:bg-red-500 hover:text-white py-2 px-4 rounded-md text-center flex items-center justify-center space-x-2 transition-all duration-300">
                                        <i class="fas fa-trash-alt text-lg"></i>
                                        <span class="hidden sm:inline">Remove</span>
                                    </button>
                                </form>
                            </div>
                            @else
                            <!-- Add to Cart Button -->
                            <form action="{{ route('cart.add', $product) }}" method="POST" class="w-full">
                                @csrf
                                <button type="submit"
                                    class="flex items-center justify-center bg-blue-500 text-white p-3 rounded-md font-medium hover:bg-blue-600 transition w-full">
                                    <i class="fas fa-cart-plus mr-2"></i>
                                    <span class="hidden sm:inline">Add to Cart</span>
                                </button>
                            </form>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Product Category & Tags -->
                <div class="mt-6 text-sm text-gray-500">
                    <p><strong>Category:</strong> <span class="text-gray-700 font-semibold">{{ $product->category->name
                            }}</span></p>
                    @if ($category->count() > 0)
                    <p class="mt-2"><strong>Tags:</strong>
                        @foreach ($category as $cat)
                        <a href="{{ route('shop.categorywiseproduct', ['category' => $cat->id]) }}"
                            class="text-blue-500 hover:text-blue-700 font-semibold">{{ $cat->name }}</a>{{ $loop->last ?
                        '' : ', ' }}
                        @endforeach
                    </p>
                    @else
                    <p class="mt-2"><strong>Tags:</strong> None available.</p>
                    @endif
                </div>

                <!-- Additional Product Information -->
                <div class="mt-6 text-sm text-gray-500 space-y-2">
                    <p><i class="fas fa-info-circle text-blue-500"></i> Secure payment processing & fast delivery.</p>
                    <p><i class="fas fa-shield-alt text-blue-500"></i> 7-days return policy on all items.</p>
                </div>
            </div>

        </div>
    </div>
</section>

<style>
    /* Custom scrollbar styles */
    .scrollbar-custom::-webkit-scrollbar {
        width: 0px;
        height: 0px;
    }

    .scrollbar-custom::-webkit-scrollbar-track {
        background: #f1f1f1;
    }

    .scrollbar-custom::-webkit-scrollbar-thumb {
        background-color: #888;
        border-radius: 10px;
    }

    .scrollbar-custom::-webkit-scrollbar-thumb:hover {
        background-color: #555;
    }

    /* Thumbnail container adjustments for vertical layout */
    #thumbnails {
        display: flex;
        flex-direction: column;
        gap: 3px;
        border: hidden;
    }

    /* Hover effect for thumbnails */
    .thumbnail:hover {
        border-color: blue;
    }
</style>

<script>
    // Change the main image when a thumbnail is clicked
        document.querySelectorAll('.thumbnail').forEach(function(thumbnail) {
            thumbnail.addEventListener('click', function() {
                const newSrc = thumbnail.getAttribute('data-image');
                const bigImage = document.getElementById('big-image');
                bigImage.src = newSrc;
            });
        });

        // Zoom functionality for the big image
        const zoomImage = document.getElementById('big-image');
        let scale = 1; // Initialize scale for zoom

        zoomImage.addEventListener('click', function() {
            const modal = document.createElement('div');
            modal.classList.add('zoomModal', 'fixed', 'inset-0', 'bg-black',
                'bg-opacity-70', 'flex', 'justify-center', 'items-center', 'z-50');

            const zoomedImg = document.createElement('img');
            zoomedImg.src = zoomImage.src;
            zoomedImg.classList.add('max-w-full', 'h-auto', 'cursor-zoom-out', 'rounded-md');

            const closeBtn = document.createElement('button');
            closeBtn.innerHTML = 'X';
            closeBtn.classList.add('absolute', 'top-4', 'right-4', 'text-white', 'p-2',
                'bg-black', 'bg-opacity-50', 'hover:bg-opacity-80', 'rounded-full');

            closeBtn.addEventListener('click', function() {
                modal.remove();
            });

            modal.appendChild(zoomedImg);
            modal.appendChild(closeBtn);
            document.body.appendChild(modal);

            // Zoom in and out using mouse wheel
            zoomedImg.addEventListener('wheel', function(event) {
                if (event.deltaY < 0) {
                    scale = Math.min(scale + 0.1, 3); // Zoom in, limit to 3x
                } else {
                    scale = Math.max(scale - 0.1, 1); // Zoom out, limit to 1x
                }
                zoomedImg.style.transform = `scale(${scale})`;
            });
        });
</script>
@endsection
