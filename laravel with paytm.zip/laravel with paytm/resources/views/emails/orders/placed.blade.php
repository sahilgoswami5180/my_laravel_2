@component('mail::message')
# Order Confirmation

Thank you for your order! Your order has been placed successfully.

**Order ID:** {{ $order->id }}
**Total Amount:** ${{ $order->total }}
**Payment Method:** Cash on Delivery

We will contact you shortly to arrange for delivery.

Thanks,
{{ config('app.name') }}
@endcomponent