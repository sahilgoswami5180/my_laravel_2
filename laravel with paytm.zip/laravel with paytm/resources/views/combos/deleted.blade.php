@extends('layouts.app')

@section('title', 'Deleted Combos')

@section('content')
    <div class="container mx-auto top-0">
        <!-- Breadcrumb Navigation -->
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700 mb-6"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('combos.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Combos</a>
                    </div>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="text-sm font-medium text-gray-700">Trashed Combos</span>
                    </div>
                </li>
            </ol>
            <!-- Action Button: View Deleted Categories aligned at the end -->
            <div class="flex items-center justify-end ml-4">
                <a href="{{ route('combos.index') }}"
                    class="bg-indigo-600 text-white px-3 py-2 rounded-full shadow-md hover:bg-indigo-800 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 text-sm">
                    Back to Combos
                </a>
            </div>

        </div>


        <!-- Trashed Combos Table -->
        @if ($deletedCombos->isEmpty())
            <div class="bg-white p-4 rounded-lg shadow-md text-center">
                <h3 class="text-xl font-semibold text-gray-600">No Combos Deleted Yet</h3>
            </div>
        @else
            <div class="overflow-x-auto bg-white rounded-lg shadow-xl mt-4">
                <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
                    <thead class="bg-gray-100 text-gray-600">
                        <tr>
                            <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                            <th class="px-6 py-3 text-center text-sm font-bold">Name</th>
                            <th class="px-6 py-3 text-center text-sm font-bold">Description</th>
                            <th class="px-6 py-3 text-center text-sm font-bold">Total Price</th>
                            <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        @foreach ($deletedCombos as $combo)
                            <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                                <td class="px-6 py-4 text-sm text-gray-800">{{ $combo->id }}</td>
                                <td class="px-6 py-4 text-sm text-gray-800">{{ $combo->name }}</td>
                                <td class="px-6 py-4 text-sm text-gray-800 break-words" style="width:200px;">
                                    {{ $combo->description }}</td>
                                <td class="px-6 py-4 text-sm text-gray-800">{{ number_format($combo->total_price, 2) }}</td>
                                <td class="px-6 py-4 text-sm text-center">
                                    <div class="flex justify-center space-x-4">
                                        <!-- Restore Button -->
                                        <form action="{{ route('combos.restore', $combo->id) }}" method="POST"
                                            style="display:inline;">
                                            @csrf
                                            <button type="submit"
                                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                                Restore
                                            </button>
                                        </form>

                                        <!-- Permanently Delete Button -->
                                        <form action="{{ route('combos.forceDelete', $combo->id) }}" method="POST"
                                            style="display:inline;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm">
                                                <i class="fas fa-trash-alt"></i> Permanently Delete
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Pagination Links -->
            <div class="mt-4 text-sm">
                {{ $deletedCombos->links() }}
            </div>
        @endif
    </div>
@endsection
